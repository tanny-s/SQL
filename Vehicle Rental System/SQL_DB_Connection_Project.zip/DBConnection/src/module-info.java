/**
 * 
 */
/**
 * 
 */
module DBConnection {
	requires java.sql;
}