package com.acc;

import java.sql.*;
import java.util.*;

import com.acc.Employee;

public class Operableimpl  implements Operable
{

	@Override
	public List<Employee> findAll() {
			Connection con=null;
			Statement stmt=null;
			ResultSet rs= null;
			List<Employee> emps =new ArrayList<>();
			//con=DBConnection.getDBConnection();
			try {
				con=DBConnection.getDBConnection();
				stmt=con.createStatement();
				rs=stmt.executeQuery("select * from employee");
				while(rs.next())
				{
					emps.add(new Employee(rs.getInt("id"),rs.getInt("age"),rs.getString("firstname"),rs.getString("lastname")));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				try {
				if(con!=null)
				{
						con.close();
					}
				}catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			return emps;
			}
			
			
	

	@Override
	public Employee find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add(Employee id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(int id, int age) {
		// TODO Auto-generated method stub
		
	}

}
