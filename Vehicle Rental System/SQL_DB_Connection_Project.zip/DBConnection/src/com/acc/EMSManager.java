package com.acc;
import com.acc.Employee;
import com.acc.Operableimpl;

import java.util.*;
public class EMSManager {
	
	public static void main(String args[])
	{
		List<Employee> employees= new ArrayList<>();
		Operableimpl ol=new Operableimpl();
		employees=ol.findAll();
		for(Employee employee:employees)
		{
			System.out.println(employees);
		}
		
	
	}
}
