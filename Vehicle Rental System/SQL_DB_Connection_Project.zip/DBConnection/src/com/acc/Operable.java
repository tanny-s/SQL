package com.acc;
import java.io.*;
import java.util.*;
import com.acc.Employee;
public interface Operable
{
	public List <Employee>findAll();
	public Employee find(int id);
	public void delete(int id);
	public void add(Employee id);
	public void update(int  id,int age);
}
